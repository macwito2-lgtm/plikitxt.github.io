LIXCRAFT - logo na scoreboard (resource pack)

Znak logo: \uE000   (w configu pluginu wpisz: "\uE000")

1) Wrzuc LixCraft-Scoreboard.zip na hosting z BEZPOSREDNIM linkiem do pobrania (GitHub Releases, Dropbox z ?dl=1 itp.).
2) server.properties:
   resource-pack=TWOJ_LINK
   resource-pack-sha1=SHA1_Z_PLIKU_SHA1.txt
   require-resource-pack=true
3) W pluginie od scoreboardu ustaw tytul na "\uE000" (TAB: scoreboard -> title).
4) Rozmiar/pozycja: plik assets/minecraft/font/default.json
   height = rozmiar logo (np. 12-24), ascent = polozenie w pionie (musi byc <= height).
   Zalecane: zostaw pierwsza linijke scoreboardu pusta, bo wieksze logo lekko na nia nachodzi.
